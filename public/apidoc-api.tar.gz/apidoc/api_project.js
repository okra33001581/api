define({
  "name": "laravel5 API文档",
  "version": "v1.0",
  "description": "本文档提供laravel5 商品，订单，收货地址，等API文档供嗨聊服务端开发人员作为参考，文档使用RESTfull风格，如有疑问请联系开发者",
  "apidoc": "0.3.0",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-01-05T07:19:27.033Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
